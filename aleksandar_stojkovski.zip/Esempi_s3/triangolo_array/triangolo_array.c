// Draw a white triangle against a black background


#include <stdio.h>  
#include <OpenGL/gl.h>
#include <GLUT/glut.h>

                
void draw() {
	glClearColor(1.0, 0.0, 0.0, 0.0);  	//definisce con quale colore cancellare la scena
										//con openGL 2.0 il nero e' lo stato di default iniziale
    glClear(GL_COLOR_BUFFER_BIT);		//cancella la scena
    glLoadIdentity();					//Matrice di trasformazione: identita'
	glColor3f(1.0, 1.0, 1.0);			//Definisce il colore degli oggetti da disegnare
    //glColor3i(INT_MAX , 0, 0);
	glOrtho(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0);	 //definisce l'area visualizzabile

    int vertexsize=3;
    GLfloat vertices[] = {
            0.0f,  0.5f, 0.0f,// Vertex 1 (X, Y, Z)
            0.5f, -0.5f, 0.0f, // Vertex 2 (X, Y, Z)
            -0.5f, -0.5f, 0.0f  // Vertex 3 (X, Y, Z)
    };


    glBegin(GL_TRIANGLES);				//definisce il poligono e i 3 vertici
    	glVertex3fv(&vertices[0*vertexsize]);
        glVertex3fv(&vertices[1*vertexsize]);
        glVertex3fv(&vertices[2*vertexsize]);

    glEnd();
	
    glFlush();							//esegue i comandi 
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);				// Inizializza libreria glut per la gestione delle finestre
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA); // Singolo buffer con modello colore RGBA
    glutCreateWindow("triangolo");  // Crea finestra (dimensioni e posizione di default) e definisce titolo
    glutDisplayFunc(draw);			// Rendering function
    glutMainLoop();					// loop infinito
}

